package carInfo;

import java.util.Scanner;
import java.util.stream.IntStream;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int carCount = Integer.parseInt(scanner.nextLine());

        IntStream
                .rangeClosed(1,carCount)
                .boxed()
                .map(n->scanner.nextLine().split(" "))
                .map(data -> {
                    Car curret = new Car();
                    curret.setMake(data[0]);
                    curret.setModel(data[1]);
                    curret.setHorsePower(Integer.parseInt(data[2]));
                    return curret;

                })
                .forEach(car -> System.out.println(car.getInfo()));
    }

}
