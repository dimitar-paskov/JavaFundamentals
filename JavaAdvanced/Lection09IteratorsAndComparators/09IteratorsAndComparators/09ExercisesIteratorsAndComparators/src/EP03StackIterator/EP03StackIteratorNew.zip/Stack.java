package EP03StackIterator;

import java.util.*;

public class Stack<T> implements Iterable<T> {

    List<T> stack;
    int top;

    public Stack() {

        this.stack = new ArrayList<>();
        this.top = -1;

    }

    public void push(T[] elem) {
        if (elem != null && elem.length > 0){
            Collections.addAll(this.stack, elem);
            this.top += elem.length;
        }

    }


//    public void push(T... element) {
//        this.stack.addAll(Arrays.asList(element));
//    }

    public void pop() {
        if (0<= this.top){
            this.stack.remove(this.top--);
        }else{
            System.out.println("No elements");
        }
    }

//    public T pop() {
//        if (this.stack.size() <= 0) {
//            System.out.println("No elements");
//        }
//        return this.stack.remove(this.stack.size() - 1);
//    }


//    @Override
//    public Iterator<T> iterator() {
//        return new Iterator<T>() {
//            int count = 0;
//            @Override
//            public boolean hasNext() {
//                return this.count < stack.size();
//            }
//
//            @Override
//            public T next() {
//                return stack.get((this.count++));
//            }
//        };
//    }


    @Override
    public Iterator<T> iterator() {
        return new StackIterator();
    }

    private final class StackIterator implements Iterator<T> {

        private int counter;

        private StackIterator() {
            this.counter = stack.size() - 1;
        }

        @Override
        public boolean hasNext() {
            return this.counter >= 0;
        }

        @Override
        public T next() {
            return stack.get(this.counter--);
        }
    }
}
