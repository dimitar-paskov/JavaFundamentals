package LabP01JarOfT;

public class Main {
}
