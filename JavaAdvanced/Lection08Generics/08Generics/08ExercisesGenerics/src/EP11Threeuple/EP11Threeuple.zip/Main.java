package EP11Threeuple;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] tokens = new String[0];
        try {
            tokens = reader.readLine().split("\\s+");

        String firestName = tokens[0];
        String secondName = tokens[1];
        String address = tokens[2];
        String town = tokens[3];
        Threeuple<String, String, String> tuple1 = new Threeuple<>(firestName + " " + secondName, address, town);


        tokens = reader.readLine().split("\\s+");
        String name = tokens[0];
        int littersofBeer  = Integer.parseInt(tokens[1]);
        Boolean drunkOrNot = tokens[2].equals("drunk");
        Threeuple<String, Integer, Boolean> tuple2 = new Threeuple<>(name, littersofBeer,drunkOrNot);


        tokens = reader.readLine().split("\\s+");
        String Pname = tokens[0];
        Double balance = Double.parseDouble(tokens[1]);
        String bankName = tokens[2];
        Threeuple<String, Double, String> tuple3 = new Threeuple<>(Pname,balance, bankName);

            System.out.println(tuple1.toString());
            System.out.println(tuple2.toString());
            System.out.println(tuple3.toString());
            
        } catch (IOException e) {
            e.printStackTrace();
        }



    }
}
