import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

//        Scanner scanner = new Scanner(System.in);
//        String line;
//        List<Birthable> birthableList = new ArrayList<>();
//
//        while (!"End".equals(line = scanner.nextLine())){
//            String[] tokens = line.split("\\s+");
//            String command = tokens[0];
//
//
//            Citizen citizen;
//            Pet pet;
//            Robot robot;
//
//
//            switch (command){
//                case "Citizen":{
//                    citizen = new Citizen(tokens[1], Integer.parseInt(tokens[2]), tokens[3], tokens[4]);
//                    birthableList.add(citizen);
//                }break;
//                case "Robot": {
//                    robot = new Robot(tokens[1], tokens[2]);
//
//                }break;
//                case "Pet": {
//                    pet = new Pet(tokens[1], tokens[2]);
//                    birthableList.add(pet);
//                }break;
//            }
//
//
//
//
//        }
//
//        String year = scanner.nextLine();
//        for (Birthable birthable :
//                birthableList) {
//            if (birthable.getBirthDate().contains("/"+year)){
//                System.out.println(birthable.getBirthDate());
//            }
//
//        }

    }
}
