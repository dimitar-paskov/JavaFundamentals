public interface Callable {
    String call();
}
