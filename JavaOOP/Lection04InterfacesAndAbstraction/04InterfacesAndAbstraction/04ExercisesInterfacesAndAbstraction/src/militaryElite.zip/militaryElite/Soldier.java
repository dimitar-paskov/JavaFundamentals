package militaryElite;

public interface Soldier {
    public String getId();

    public String getFirstName();

    public String getLastName();
}
