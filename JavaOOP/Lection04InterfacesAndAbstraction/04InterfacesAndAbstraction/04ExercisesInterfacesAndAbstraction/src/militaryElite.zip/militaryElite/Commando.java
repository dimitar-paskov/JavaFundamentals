package militaryElite;

public interface Commando extends Private{
    void completeMission();
}
