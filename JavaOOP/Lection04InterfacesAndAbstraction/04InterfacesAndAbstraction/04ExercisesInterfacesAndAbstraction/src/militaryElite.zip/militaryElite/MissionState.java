package militaryElite;

public enum  MissionState {
    inProgress,
    finished;
}
