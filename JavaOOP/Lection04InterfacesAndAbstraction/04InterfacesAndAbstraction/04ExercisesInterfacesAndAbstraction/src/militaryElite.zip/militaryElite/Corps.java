package militaryElite;

public enum Corps {
    Airforces,
    Marines;

}
