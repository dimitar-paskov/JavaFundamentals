package carTrip;

import static org.junit.Assert.*;

public class CarTest {

    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS CAR

}