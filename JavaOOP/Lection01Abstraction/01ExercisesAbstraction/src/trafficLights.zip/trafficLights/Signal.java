package trafficLights;

public enum Signal {
    RED, GREEN, YELLOW;
}
