package p04_WorkForce.Interfaces;

public interface Employee {
    String getName();
    int getWeeklyWorkHours();
}
