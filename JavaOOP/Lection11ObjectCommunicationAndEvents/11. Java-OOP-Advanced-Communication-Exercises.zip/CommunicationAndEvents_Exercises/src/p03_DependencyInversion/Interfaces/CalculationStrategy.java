package p03_DependencyInversion.Interfaces;


public interface CalculationStrategy {
    int calculate(int firstOperand, int secondOperand);
}
