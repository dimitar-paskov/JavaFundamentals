package p05_KingsGambitExtended.Interface;

public interface Attackable {
    void respondToAttack();
}
