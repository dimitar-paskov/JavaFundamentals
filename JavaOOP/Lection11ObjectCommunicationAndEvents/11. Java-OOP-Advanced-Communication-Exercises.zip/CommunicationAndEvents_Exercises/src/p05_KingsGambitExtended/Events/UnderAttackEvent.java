package p05_KingsGambitExtended.Events;

import java.util.EventObject;

public class UnderAttackEvent extends EventObject {
    public UnderAttackEvent(Object source) {
        super(source);
    }
}
