import core.ManagerControllerImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        ManagerControllerImpl manager = new ManagerControllerImpl();

        String input="";

        while (!"Exit".equals(input= br.readLine())){

            String[] tokens = input.split("\\s+");
            String command = tokens[0];

            String result = "";
            switch (command){
                case "AddPlayer":{
                    result = manager.addPlayer(tokens[1], tokens[2]);
                }break;
                case "AddCard":{
                    result = manager.addCard(tokens[1], tokens[2]);
                }break;
                case "AddPlayerCard":{
                    result = manager.addPlayerCard(tokens[1], tokens[2]);
                }break;
                case "Fight":{
                    result = manager.fight(tokens[1], tokens[2]);
                }break;
                case "Report":{
                    result = manager.report();
                }break;
            }

            System.out.println(result);

        }
    }
}
